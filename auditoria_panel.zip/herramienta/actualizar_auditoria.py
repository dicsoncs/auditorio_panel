#!/usr/bin/env python3
"""
Migra / actualiza el dashboard AUDIT CONTROL al Panel SOC.

Uso:
    python3 herramienta/actualizar_auditoria.py <Audit_Control_*.html> [carpeta_static]

Genera:
    static/auditoria.html     -> dashboard (logica original intacta, sin datos embebidos)
    static/auditoria_data.js  -> datos (window.AUDIT_DATA = {...})

Para actualizar solo los datos con una nueva version del HTML de Gloria,
vuelve a ejecutar el script con el nuevo archivo y haz commit/push.
"""
import json, re, sys, pathlib, datetime

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = pathlib.Path(sys.argv[1])
    out = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else "static")
    out.mkdir(parents=True, exist_ok=True)
    html = src.read_text(encoding="utf-8")

    m = re.search(r"const DATA=(\{.*?\});\s*\n\s*const qs=DATA\.questions", html, re.S)
    if not m:
        sys.exit("ERROR: no se encontro 'const DATA={...}' en el HTML de origen")
    data = json.loads(m.group(1))  # valida que el JSON sea correcto
    for k in ("rows", "questions", "fc"):
        if k not in data:
            sys.exit(f"ERROR: falta la clave '{k}' en DATA")

    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    js = (f"/* AUDIT CONTROL - datos generados {stamp} desde {src.name} */\n"
          "window.AUDIT_DATA=" + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n")
    (out / "auditoria_data.js").write_text(js, encoding="utf-8")

    guard = ('if(!window.AUDIT_DATA){document.body.innerHTML='
             '"<p style=\\"padding:30px;font-family:Segoe UI\\">No se pudo cargar auditoria_data.js</p>";'
             'throw new Error("AUDIT_DATA no cargado");}\n  const DATA=window.AUDIT_DATA;\n  const qs=DATA.questions')
    new_html = html[:m.start()] + guard + html[m.end():]
    # cargar los datos antes del script principal (mantiene las funciones globales de los onclick)
    new_html = new_html.replace("<script>const DATA=window.AUDIT_DATA",
                                '<script src="auditoria_data.js?v=' + datetime.datetime.now().strftime("%Y%m%d%H%M") +
                                '"></script>\n<script>const DATA=window.AUDIT_DATA', 1)
    if 'src="auditoria_data.js' not in new_html:
        new_html = new_html.replace(guard, guard, 1)
        idx = new_html.find(guard)
        tag = new_html.rfind("<script>", 0, idx)
        new_html = new_html[:tag] + '<script src="auditoria_data.js?v=' + \
            datetime.datetime.now().strftime("%Y%m%d%H%M") + '"></script>\n' + new_html[tag:]
    (out / "auditoria.html").write_text(new_html, encoding="utf-8")

    print(f"OK auditoria.html ({len(new_html)//1024} KB) y auditoria_data.js "
          f"({len(js)//1024} KB) -> {out}/")
    print(f"   Registros: {len(data['rows'])} | Preguntas: {len(data['questions'])} | FC: {len(data['fc'])}")

if __name__ == "__main__":
    main()

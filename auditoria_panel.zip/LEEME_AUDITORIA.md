# AUDIT CONTROL en Panel SOC (Oracle)

Archivos:
- static/auditoria.html          -> dashboard (misma lógica de la V6, sin datos embebidos)
- static/auditoria_data.js       -> datos (53 auditorías, 29 preguntas, FC)
- herramienta/actualizar_auditoria.py -> regenera ambos desde un nuevo HTML de Gloria

Actualizar datos en el futuro:
    python3 herramienta/actualizar_auditoria.py ~/Audit_Control_NUEVO.html static
    git add static/auditoria.html static/auditoria_data.js
    git commit -m "Auditoria: actualizacion de datos" && git push
